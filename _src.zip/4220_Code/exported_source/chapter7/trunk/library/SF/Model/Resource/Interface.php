<?php
/**
 * SF_Model_Resource_Interface
 * 
 * General resource interface
 * 
 * @category   Storefront
 * @package    SF_Model_Resource
 * @copyright  Copyright (c) 2008 Keith Pope (http://www.thepopeisdead.com)
 * @license    http://www.thepopeisdead.com/license.txt     New BSD License
 */
interface SF_Model_Resource_Interface 
{}