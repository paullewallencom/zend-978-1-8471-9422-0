<?php
require '../application/application.php';