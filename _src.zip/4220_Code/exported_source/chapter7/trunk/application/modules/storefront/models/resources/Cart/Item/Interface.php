<?php
interface Storefront_Resource_Cart_Item_Interface
{
    public function getLineCost();
}