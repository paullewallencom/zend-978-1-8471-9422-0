<?php
/**
 * SF_Acl_Exception
 *
 * @category   Storefront
 * @package    SF_Acl
 * @copyright  Copyright (c) 2008 Keith Pope (http://www.thepopeisdead.com)
 * @license    http://www.thepopeisdead.com/license.txt     New BSD License
 */
class SF_Acl_Exception extends SF_Exception
{}
