<?php
/**
 * SF_Acl_Interface
 *
 * @category   Storefront
 * @package    SF_Acl
 * @copyright  Copyright (c) 2008 Keith Pope (http://www.thepopeisdead.com)
 * @license    http://www.thepopeisdead.com/license.txt     New BSD License
 */
interface SF_Acl_Interface
{}
