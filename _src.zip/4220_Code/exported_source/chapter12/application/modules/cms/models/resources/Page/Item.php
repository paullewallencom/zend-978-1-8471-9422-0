<?php
/**
 * Cms_Resource_Page_Item
 *
 * @category   Cms
 * @package    Cms_Model_Resource
 * @copyright  Copyright (c) 2008 Keith Pope (http://www.thepopeisdead.com)
 * @license    http://www.thepopeisdead.com/license.txt     New BSD License
 */
class Cms_Resource_Page_Item extends SF_Model_Resource_Db_Table_Row_Abstract implements Cms_Resource_Page_Item_Interface
{}
