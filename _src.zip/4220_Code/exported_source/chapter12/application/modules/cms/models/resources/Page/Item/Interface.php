<?php
/**
 * Cms_Resource_Page_Item_Interface
 *
 * @category   Cms
 * @package    Cms_Model_Resource
 * @copyright  Copyright (c) 2008 Keith Pope (http://www.thepopeisdead.com)
 * @license    http://www.thepopeisdead.com/license.txt     New BSD License
 */
interface Cms_Resource_Page_Item_Interface
{}