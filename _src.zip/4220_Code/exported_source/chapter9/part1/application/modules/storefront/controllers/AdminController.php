<?php
class Storefront_AdminController extends Zend_Controller_Action
{
	public function indexAction()
	{}
}
